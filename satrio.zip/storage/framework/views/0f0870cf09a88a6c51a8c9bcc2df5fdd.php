<?php $__env->startComponent('mail::message'); ?>
# Terima Kasih Telah Memesan!

Pesanan Anda sudah kami terima dan sedang diproses.

<?php $__env->startComponent('mail::button', ['url' => $url]); ?>
Lihat Detail Pesanan
<?php echo $__env->renderComponent(); ?>

Terima kasih telah berbelanja di FroozenFood!
Salam hangat,
**FroozenFood Team**
<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\Users\Acer\Desktop\satrio\satrio\resources\views/mail/orders/placed.blade.php ENDPATH**/ ?>