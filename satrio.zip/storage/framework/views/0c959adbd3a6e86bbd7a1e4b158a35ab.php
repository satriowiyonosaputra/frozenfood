<div>

<div class="w-full h-screen bg-gradient-to-br from-blue-300 via-blue-200 to-blue-100 py-10 px-4 sm:px-6 lg:px-8 mx-auto">

  <div class="max-w-[85rem] mx-auto px-4 sm:px-6 lg:px-8">
    <!-- Grid -->
    <div class="grid md:grid-cols-2 gap-4 md:gap-8 xl:gap-20 md:items-center">
      <div>
        <h1 class="block text-3xl font-bold text-white-800 sm:text-4xl lg:text-6xl lg:leading-tight dark:text-white">Mulailah perjalanan Anda dengan <span class="text-blue-600">FrozenFood</span></h1>
        <p class="mt-3 text-lg text-gray-800 dark:text-white-400">"Frozen Food Berkualitas, Siap Dalam Sekejap!"
            Dari cemilan gurih hingga lauk harian semua tersedia praktis, higienis, dan tahan lama.</p>

        <!-- Buttons -->
        <div class="mt-7 grid gap-3 w-full sm:inline-flex">
          <a class="py-3 px-4 inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-900" href="/products">
            Memulai
            <svg class="flex-shrink-0 w-4 h-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m9 18 6-6-6-6" />
            </svg>
          </a>
          <a class="py-3 px-4 inline-flex justify-center items-center gap-x-2 text-sm font-medium rounded-lg border border-white-200 bg-white text-white-800 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-white-900 dark:border-gray-700 dark:text-black dark:hover:bg-gray-800 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600" href="https://wa.me/6281215139093">
            Hubungi tim penjual
          </a>
        </div>
        <!-- End Buttons -->

        <!-- Review -->
        <div class="mt-6 lg:mt-10 grid grid-cols-2 gap-x-5">
          <!-- Review -->
          <div class="py-5">
            

          </div>
          <!-- End Review -->


        </div>
        <!-- End Review -->
      </div>
      <!-- End Col -->

      <div class="relative ms-4">
        <img class="w-full rounded-md" src="<?php echo e(asset('assets/storage/brands/ioo.PNG')); ?>" alt="Image Description">


        <!-- SVG-->
        <div class="absolute bottom-0 start-0">
          <svg class="w-2/3 ms-auto h-auto text-white dark:text-slate-900" width="630" height="451" viewBox="0 0 630 451" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="531" y="352" width="99" height="99" fill="currentColor" />
            <rect x="140" y="352" width="106" height="99" fill="currentColor" />
            <rect x="482" y="402" width="64" height="49" fill="currentColor" />
            <rect x="433" y="402" width="63" height="49" fill="currentColor" />
            <rect x="384" y="352" width="49" height="50" fill="currentColor" />
            <rect x="531" y="328" width="50" height="50" fill="currentColor" />
            <rect x="99" y="303" width="49" height="58" fill="currentColor" />
            <rect x="99" y="352" width="49" height="50" fill="currentColor" />
            <rect x="99" y="392" width="49" height="59" fill="currentColor" />
            <rect x="44" y="402" width="66" height="49" fill="currentColor" />
            <rect x="234" y="402" width="62" height="49" fill="currentColor" />
            <rect x="334" y="303" width="50" height="49" fill="currentColor" />
            <rect x="581" width="49" height="49" fill="currentColor" />
            <rect x="581" width="49" height="64" fill="currentColor" />
            <rect x="482" y="123" width="49" height="49" fill="currentColor" />
            <rect x="507" y="124" width="49" height="24" fill="currentColor" />
            <rect x="531" y="49" width="99" height="99" fill="currentColor" />
          </svg>
        </div>
        <!-- End SVG-->
      </div>
      <!-- End Col -->
    </div>
    <!-- End Grid -->
  </div>
</div>



<section class="bg-white dark:bg-blue-100 py-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="text-center mb-10">
        <h2 class="text-3xl font-extrabold text-gray-900 dark:text-black">
          Kenapa Belanja di Kami?
        </h2>
        <p class="mt-3 text-lg text-gray-600 dark:text-black-300 max-w-2xl mx-auto">
          Layanan terbaik kami siap memastikan pengalaman belanja frozen food Anda cepat, aman, dan menyenangkan.
        </p>
      </div>

      <div class="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
        <!-- Pengiriman Cepat -->
        <div class="text-center p-6 bg-gray-50 dark:bg-gray-800 rounded-2xl shadow hover:shadow-lg transition">
          <div class="flex items-center justify-center w-16 h-16 mx-auto mb-4 text-white bg-blue-600 rounded-full">
            <!-- Truck icon -->
            <svg class="w-8 h-8" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
              <path d="M3 13V6a1 1 0 0 1 1-1h11v8H3zm11 0h3.586a1 1 0 0 1 .707.293l3.414 3.414A1 1 0 0 1 22 17V18a2 2 0 0 1-2 2h-1a2 2 0 1 1-4 0H9a2 2 0 1 1-4 0H4a2 2 0 0 1-2-2v-1h12z" />
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-gray-900 dark:text-white">Pengiriman Cepat</h3>
          <p class="mt-2 text-gray-600 dark:text-gray-300 text-sm">
            Pesanan dikirim dalam hitungan jam ke wilayah Jepara sehingga tetap segar & beku.
          </p>
        </div>

        <!-- Produk Higienis -->
        <div class="text-center p-6 bg-gray-50 dark:bg-gray-800 rounded-2xl shadow hover:shadow-lg transition">
          <div class="flex items-center justify-center w-16 h-16 mx-auto mb-4 text-white bg-green-600 rounded-full">
            <!-- Shield check icon -->
            <svg class="w-8 h-8" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
              <path d="M12 3l7.5 4v5c0 4.97-3.58 9.57-8 11-4.42-1.43-8-6.03-8-11V7l8-4z" />
              <path d="M9 12l2 2 4-4" />
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-gray-900 dark:text-white">Produk Higienis</h3>
          <p class="mt-2 text-gray-600 dark:text-gray-300 text-sm">
            Diproses secara higienis dengan standar tinggi, langsung dikemas dan dibekukan untuk menjaga kesegaran.
          </p>
        </div>

        <!-- Beku Maksimal -->
        <div class="text-center p-6 bg-gray-50 dark:bg-gray-800 rounded-2xl shadow hover:shadow-lg transition">
          <div class="flex items-center justify-center w-16 h-16 mx-auto mb-4 text-white bg-cyan-600 rounded-full">
            <!-- Snowflake icon -->
            <svg class="w-8 h-8" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
              <path d="M12 2v20M4.93 4.93l14.14 14.14M2 12h20M4.93 19.07l14.14-14.14" />
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-gray-900 dark:text-white">Beku Maksimal</h3>
          <p class="mt-2 text-gray-600 dark:text-gray-300 text-sm">
            Teknologi pendinginan cepat menjaga kesegaran dan kualitas nutrisi makanan.
          </p>
        </div>

        <!-- Praktis Siap Masak -->
        <div class="text-center p-6 bg-gray-50 dark:bg-gray-800 rounded-2xl shadow hover:shadow-lg transition">
          <div class="flex items-center justify-center w-16 h-16 mx-auto mb-4 text-white bg-purple-600 rounded-full">
            <!-- Cooking pot icon -->
            <svg class="w-8 h-8" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
              <path d="M4 10h16v2a6 6 0 0 1-6 6H10a6 6 0 0 1-6-6v-2zm0-2h16v2H4v-2zm3-2h10a1 1 0 0 1 1 1v1H6V7a1 1 0 0 1 1-1z" />
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-gray-900 dark:text-white">Praktis Siap Masak</h3>
          <p class="mt-2 text-gray-600 dark:text-gray-300 text-sm">
            Cukup panaskan, goreng, atau kukus dan makanan siap dalam hitungan menit.
          </p>
        </div>
      </div>
    </div>
  </section>




<section class="py-20">
  <div class="max-w-xl mx-auto">
    <div class="text-center ">
      <div class="relative flex flex-col items-center">
        <h1 class="text-5xl font-bold dark:text-gray-500"> Jelajahi Populer<span class="text-blue-500">Merek
          </span> </h1>
        <div class="flex w-40 mt-2 mb-6 overflow-hidden rounded">
          <div class="flex-1 h-2 bg-blue-200">
          </div>
          <div class="flex-1 h-2 bg-blue-400">
          </div>
          <div class="flex-1 h-2 bg-blue-600">
          </div>
        </div>
      </div>
      <p class="mb-12 text-base text-center text-black mt-5 mb-7">
        Temukan berbagai merek frozen food terpopuler yang sudah terpercaya kualitas dan rasanya. Mulai dari pilihan camilan, daging olahan, hingga makanan siap saji dari brand favorit keluarga Indonesia. Jelajahi dan temukan produk andalanmu sekarang!
      </p>
    </div>
  </div>
  <div class="justify-center max-w-6xl px-4 py-4 mx-auto lg:py-0">
    <div class="grid grid-cols-1 gap-6 lg:grid-cols-4 md:grid-cols-2">

    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="bg-white rounded-lg shadow-md dark:bg-gray-800" wire:key="<?php echo e($brand->id); ?>">
    <a href="/products?selected_brands[0]=<?php echo e($brand->id); ?>" class="">
        <img src="<?php echo e(url('storage/' . $brand->image)); ?>" alt="<?php echo e($brand->name); ?>" class="object-cover w-full h-64 rounded-t-lg">
    </a>
    <div class="p-5 text-center">
        <a href="" class="text-2xl font-bold tracking-tight text-gray-900 dark:text-gray-300">
            <?php echo e($brand->name); ?>

        </a>
    </div>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

    </div>
  </div>
</section>



<div class="bg-blue-200 py-20">
  <div class="max-w-xl mx-auto">
    <div class="text-center ">
      <div class="relative flex flex-col items-center">
        <h1 class="text-5xl font-bold dark:text-gray-500"> Jelajahi <span class="text-blue-500"> Kategori
          </span> </h1>
        <div class="flex w-40 mt-2 mb-6 overflow-hidden rounded">
          <div class="flex-1 h-2 bg-blue-200">
          </div>
          <div class="flex-1 h-2 bg-blue-400">
          </div>
          <div class="flex-1 h-2 bg-blue-600">
          </div>
        </div>
      </div>
      <p class="mb-12 text-base text-center text-white-500">
        Jelajahi berbagai kategori frozen food untuk memenuhi kebutuhan harianmu! Mulai dari makanan siap saji, daging olahan, seafood, sayuran beku, hingga camilan lezat—semua tersedia dalam satu tempat. Pilih sesuai selera dan praktis untuk disajikan kapan saja!
      </p>
    </div>
  </div>

  <div class="max-w-[85rem] px-4 sm:px-6 lg:px-8 mx-auto">
    <div class="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">

    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <a class="group flex flex-col bg-white border shadow-sm rounded-xl hover:shadow-md transition dark:bg-slate-900 dark:border-gray-800 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600" href="/products?selected_categories[0]=<?php echo e($category->id); ?>"
        >
        <div class="p-4 md:p-5">
          <div class="flex justify-between items-center">
            <div class="flex items-center">
              <img class="h-[2.375rem] w-[2.375rem] rounded-full" src="<?php echo e(url('storage',$category->image)); ?>" alt="<?php echo e($category->name); ?>">
              <div class="ms-3">
                <h3 class="group-hover:text-blue-600 font-semibold text-gray-800 dark:group-hover:text-gray-400 dark:text-gray-200">
                <?php echo e($category->name); ?>

                </h3>
              </div>
            </div>
            <div class="ps-3">
              <svg class="flex-shrink-0 w-5 h-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="m9 18 6-6-6-6" />
              </svg>
            </div>
          </div>
        </div>

      </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->



    </div>
  </div>
  


</div>
</div>

<?php /**PATH C:\Users\Acer\Desktop\satrio\satrio\resources\views/livewire/home-page.blade.php ENDPATH**/ ?>